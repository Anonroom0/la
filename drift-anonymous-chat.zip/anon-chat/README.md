# Drift — Anonymous 1:1 Chat Platform

A premium, production-ready anonymous chat platform with instant random matchmaking, real-time messaging, and built-in moderation. Built with Next.js 15, Socket.IO, Prisma/PostgreSQL, and Redis.

![Drift](public/icons/icon-512.png)

## ✨ Features

- **Landing page** — animated gradient mesh background, glassmorphism cards, floating particles, FAQ, privacy & safety sections
- **Matchmaking** — Redis-backed queue with gender/country preferences and interest-tag matching, skip/leave/auto-reconnect
- **Chat** — real-time messaging, typing indicators, read receipts, emoji picker, image sharing, connection quality indicator
- **Safety** — spam heuristics, profanity filtering, Redis rate limiting, report/block flows, automated temporary bans
- **Admin dashboard** — live stats, report queue with one-click moderation actions, ban management, activity log
- **PWA** — installable, mobile-first, offline-friendly manifest
- **Security** — Helmet, CSRF-safe cookies, input sanitization, hashed identifiers (no PII ever stored)

## 🏗️ Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 15 (App Router) + TypeScript |
| Styling | Tailwind CSS + shadcn/ui (Radix primitives) |
| Animation | Framer Motion |
| Realtime | Socket.IO (custom Express server) |
| Database | PostgreSQL via Prisma ORM |
| Cache / Queue | Redis (ioredis) |
| Auth (admin) | JWT in httpOnly cookies |
| Deployment | Docker, Docker Compose, Railway, Render, Vercel |

## 📁 Project Structure

```
drift/
├── server/                  # Custom Express + Socket.IO server
│   ├── index.ts             # Server entrypoint (security middleware, Next.js handoff)
│   └── socket/
│       ├── handlers.ts      # All socket event handlers
│       └── matchmaking.ts   # Redis-backed queue & matching algorithm
├── src/
│   ├── app/                 # Next.js App Router pages & API routes
│   │   ├── page.tsx         # Landing page
│   │   ├── chat/page.tsx    # Chat experience
│   │   ├── admin/           # Admin login + dashboard
│   │   └── api/             # REST endpoints
│   ├── components/
│   │   ├── ui/               # shadcn-style primitives
│   │   ├── landing/           # Hero, features, FAQ, footer
│   │   └── chat/               # Queue screen, chat header, composer, messages
│   ├── hooks/use-socket.ts   # Client socket lifecycle + identity persistence
│   ├── lib/                  # prisma, redis, moderation, rate-limit, identity, auth
│   └── types/socket.ts       # Shared Socket.IO event contract
├── prisma/schema.prisma     # Sessions, Reports, Bans, Preferences, Analytics, Admin
├── Dockerfile
└── docker-compose.yml
```

## 🚀 Getting Started

### Prerequisites
- Node.js 20+
- PostgreSQL 16+ (or use Docker Compose)
- Redis 7+ (or use Docker Compose)

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# edit .env with your DATABASE_URL, REDIS_URL, and secrets
```

### 3. Set up the database
```bash
npm run db:generate
npm run db:push
```

### 4. Run the dev server
```bash
npm run dev
```
Visit `http://localhost:3000`.

### 5. (Optional) Run everything via Docker Compose
```bash
docker compose up --build
```
This spins up the app, PostgreSQL, and Redis together.

## 🔑 Environment Variables

| Variable | Description |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `NEXT_PUBLIC_APP_URL` | Public base URL (used in metadata, CORS, sitemap) |
| `IDENTITY_PEPPER` | Server-side pepper for hashing device fingerprints/IPs |
| `ADMIN_JWT_SECRET` | Secret used to sign admin session JWTs |
| `ADMIN_PASSWORD_SALT` | Salt used for hashing admin passwords stored in DB |
| `ADMIN_BOOTSTRAP_USERNAME` / `ADMIN_BOOTSTRAP_PASSWORD` | First-run admin login before seeding the `Admin` table |

## 🔌 API Documentation

### REST Endpoints

| Method | Route | Description | Auth |
|---|---|---|---|
| `GET` | `/api/health` | Liveness/readiness probe (checks DB + Redis) | None |
| `POST` | `/api/admin/login` | Admin login, sets httpOnly JWT cookie | None |
| `GET` | `/api/admin/stats` | Platform stats (online count, reports, bans, events) | Admin |
| `GET` | `/api/admin/reports?status=pending` | List reports by status | Admin |
| `POST` | `/api/admin/reports` | Action a report: `dismiss` \| `ban_temp` \| `ban_permanent` | Admin |
| `GET` | `/api/admin/bans` | List active bans | Admin |
| `DELETE` | `/api/admin/bans` | Lift a ban (`{ banId }`) | Admin |

### Socket.IO Events

**Client → Server**
- `queue:join({ genderPref, countryPref, interests })`
- `queue:leave()`
- `chat:message({ pairId, text?, imageUrl?, gifUrl? })`
- `chat:typing({ pairId, isTyping })`
- `chat:read({ pairId, messageId })`
- `chat:skip({ pairId })`
- `chat:leave({ pairId })`
- `user:report({ pairId, reason, details? })`
- `user:block({ pairId })`
- `ping:latency(clientSentAt)`

**Server → Client**
- `queue:waiting({ position, estimatedSeconds })`
- `queue:matched({ pairId, anonHandle, country, sharedInterests })`
- `chat:message(message)`
- `chat:typing({ isTyping })`
- `chat:read({ messageId })`
- `chat:partner-left({ reason })`
- `user:warning({ message })`
- `user:banned({ reason, expiresAt })`
- `presence:online-count(count)`
- `pong:latency(rttMs)`
- `error:rate-limited({ bucket, retryAfterSeconds })`

Full type definitions live in `src/types/socket.ts`.

## 🛡️ Security Notes

- All HTTP responses include strict security headers via Helmet and `next.config.js`.
- Admin sessions use httpOnly, `SameSite=strict`, secure-in-production cookies.
- No raw IP addresses or device fingerprints are ever persisted — only salted SHA-256 hashes.
- All chat input is sanitized (HTML stripped) before broadcast.
- Redis-backed rate limiting protects matchmaking, messaging, and reporting endpoints from abuse.

## 📦 Deployment

### Vercel
Deploy the Next.js app to Vercel, and run the Socket.IO server as a separate Node process (Vercel's serverless functions don't support persistent WebSocket connections) — e.g. on Railway or Render. Point `NEXT_PUBLIC_APP_URL` at your Socket.IO server's URL.

### Railway / Render
Both platforms support the included `Dockerfile` directly:
1. Create a new service from this repository.
2. Add PostgreSQL and Redis plugins (or external instances) and set `DATABASE_URL` / `REDIS_URL`.
3. Set the remaining environment variables from `.env.example`.
4. Deploy — the `Dockerfile` builds and runs the custom server (`npm run start`), which serves both the Next.js app and Socket.IO on the same port.

### Docker Compose (self-hosted / VPS)
```bash
docker compose up -d --build
```

## 🧪 Useful Scripts

```bash
npm run dev          # Start dev server (tsx watch on the custom server)
npm run build         # Build the Next.js app for production
npm run start          # Run the production server
npm run db:push        # Push Prisma schema to the database
npm run db:migrate     # Create & apply a migration
npm run db:studio      # Open Prisma Studio
```

## 📄 License

MIT — build something great with it.

import { Navbar, Footer } from "@/components/landing/footer-navbar";
import { AnimatedBackground } from "@/components/landing/animated-background";

export const metadata = { title: "About" };

export default function AboutPage() {
  return (
    <main className="relative">
      <AnimatedBackground />
      <Navbar />
      <div className="mx-auto max-w-2xl px-4 pb-20 pt-32 prose prose-invert prose-sm">
        <h1 className="text-3xl font-bold">About Drift</h1>
        <p className="text-muted-foreground">
          Drift is a premium, anonymous one-to-one chat platform built for genuine, unfiltered conversation. No
          accounts, no profiles, no algorithms tracking your social graph — just a fast, safe way to meet someone new.
        </p>
        <p className="mt-4 text-muted-foreground">
          Every match is powered by a real-time matchmaking engine that pairs you instantly based on your optional
          preferences, while built-in moderation keeps the experience welcoming for everyone.
        </p>
      </div>
      <Footer />
    </main>
  );
}

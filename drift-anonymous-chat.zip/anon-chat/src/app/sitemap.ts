import type { MetadataRoute } from "next";

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "https://drift.chat";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ["", "/chat", "/about", "/privacy", "/safety"];
  return routes.map((route) => ({
    url: `${APP_URL}${route}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: route === "" ? 1 : 0.7,
  }));
}

import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { ToastProvider } from "@/components/ui/toast";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "https://drift.chat";

export const metadata: Metadata = {
  metadataBase: new URL(APP_URL),
  title: {
    default: "Drift — Anonymous 1:1 Chat",
    template: "%s · Drift",
  },
  description:
    "Drift pairs you instantly with a stranger for real, anonymous conversation. No signup, no profiles, just the moment.",
  keywords: ["anonymous chat", "random chat", "stranger chat", "omegle alternative", "talk to strangers"],
  manifest: "/manifest.json",
  icons: { icon: "/icons/icon-192.png", apple: "/icons/icon-192.png" },
  openGraph: {
    title: "Drift — Anonymous 1:1 Chat",
    description: "Instant, anonymous, one-on-one conversations with strangers around the world.",
    url: APP_URL,
    siteName: "Drift",
    type: "website",
    images: [{ url: "/og-image.png", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Drift — Anonymous 1:1 Chat",
    description: "Instant, anonymous, one-on-one conversations with strangers around the world.",
    images: ["/og-image.png"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#06060a",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable} suppressHydrationWarning>
      <body className="min-h-screen font-sans">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}

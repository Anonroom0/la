"use client";

import { Hero } from "@/components/landing/hero";
import { Features } from "@/components/landing/features";
import { SafetySection, PrivacySection } from "@/components/landing/safety-privacy";
import { FAQ } from "@/components/landing/faq";
import { Footer, Navbar } from "@/components/landing/footer-navbar";
import { AnimatedBackground } from "@/components/landing/animated-background";

export default function HomePage() {
  return (
    <main className="relative">
      <AnimatedBackground />
      <Navbar />
      <Hero />
      <Features />
      <SafetySection />
      <PrivacySection />
      <FAQ />
      <Footer />
    </main>
  );
}

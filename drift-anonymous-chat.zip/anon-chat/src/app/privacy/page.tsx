import { Navbar, Footer } from "@/components/landing/footer-navbar";
import { AnimatedBackground } from "@/components/landing/animated-background";

export const metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <main className="relative">
      <AnimatedBackground />
      <Navbar />
      <div className="mx-auto max-w-2xl px-4 pb-20 pt-32 prose prose-invert prose-sm">
        <h1 className="text-3xl font-bold">Privacy Policy</h1>
        <p className="text-muted-foreground">Last updated {new Date().toLocaleDateString()}</p>

        <h2 className="mt-8 text-xl font-semibold">What we collect</h2>
        <p className="text-muted-foreground">
          Drift does not require registration. We do not collect names, emails, or phone numbers. To prevent abuse,
          we generate a one-way hash of your device fingerprint and IP address — the raw values are never stored.
        </p>

        <h2 className="mt-8 text-xl font-semibold">Messages</h2>
        <p className="text-muted-foreground">
          Chat messages are relayed in real time between you and your matched partner and are not persisted to our
          database by default. A short snapshot of recent messages may be retained temporarily only if you or your
          partner file a report, to support moderation review.
        </p>

        <h2 className="mt-8 text-xl font-semibold">Analytics</h2>
        <p className="text-muted-foreground">
          We log anonymized, aggregate events (such as queue joins and match counts) to operate and improve the
          service. These events are tied to your anonymous session ID only, never to personal information.
        </p>

        <h2 className="mt-8 text-xl font-semibold">Your choices</h2>
        <p className="text-muted-foreground">
          Clearing your browser storage rotates your anonymous identity. You can block or report any user directly
          from the chat interface.
        </p>
      </div>
      <Footer />
    </main>
  );
}

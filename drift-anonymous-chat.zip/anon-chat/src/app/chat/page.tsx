"use client";

import { useCallback, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useSocket } from "@/hooks/use-socket";
import { useToast } from "@/components/ui/toast";
import { QueueScreen } from "@/components/chat/queue-screen";
import { ChatHeader } from "@/components/chat/chat-header";
import { MessageList } from "@/components/chat/message-list";
import { Composer } from "@/components/chat/composer";
import { ReportDialog } from "@/components/chat/report-dialog";
import { AnimatedBackground } from "@/components/landing/animated-background";
import type { ChatMessage, MatchedPartner, MatchPreferences } from "@/types/socket";

type ViewState = "idle" | "searching" | "matched";

export default function ChatPage() {
  const { socket, connected, quality, onlineCount } = useSocket();
  const { toast } = useToast();

  const [view, setView] = useState<ViewState>("idle");
  const [queuePosition, setQueuePosition] = useState(0);
  const [partner, setPartner] = useState<MatchedPartner | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [partnerTyping, setPartnerTyping] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [selfId, setSelfId] = useState("");

  useEffect(() => {
    if (!socket) return;

    socket.on("connect", () => setSelfId(socket.id ?? ""));

    socket.on("queue:waiting", ({ position }) => {
      setView("searching");
      setQueuePosition(position);
    });

    socket.on("queue:matched", (matchedPartner) => {
      setPartner(matchedPartner);
      setMessages([]);
      setView("matched");
      toast({ title: "Connected!", description: `You're now chatting with ${matchedPartner.anonHandle}`, variant: "success" });
    });

    socket.on("chat:message", (message) => {
      setMessages((prev) => [...prev, message]);
    });

    socket.on("chat:typing", ({ isTyping }) => setPartnerTyping(isTyping));

    socket.on("chat:partner-left", ({ reason }) => {
      setView("idle");
      setPartner(null);
      const copy =
        reason === "skip" ? "Your partner skipped to a new chat." :
        reason === "report" ? "Chat ended after a report was filed." :
        "Your partner disconnected.";
      toast({ title: "Chat ended", description: copy, variant: "warning" });
    });

    socket.on("user:warning", ({ message }) => {
      toast({ title: "Heads up", description: message, variant: "warning" });
    });

    socket.on("user:banned", ({ reason }) => {
      toast({ title: "You've been temporarily banned", description: reason, variant: "error" });
      setView("idle");
    });

    socket.on("error:rate-limited", ({ retryAfterSeconds }) => {
      toast({ title: "Slow down", description: `Try again in ${retryAfterSeconds}s.`, variant: "warning" });
    });

    return () => {
      socket.off("connect");
      socket.off("queue:waiting");
      socket.off("queue:matched");
      socket.off("chat:message");
      socket.off("chat:typing");
      socket.off("chat:partner-left");
      socket.off("user:warning");
      socket.off("user:banned");
      socket.off("error:rate-limited");
    };
  }, [socket, toast]);

  const startQueue = useCallback(
    (prefs: MatchPreferences) => {
      socket?.emit("queue:join", prefs);
      setView("searching");
    },
    [socket]
  );

  const cancelQueue = useCallback(() => {
    socket?.emit("queue:leave");
    setView("idle");
  }, [socket]);

  const skip = useCallback(() => {
    if (!partner) return;
    socket?.emit("chat:skip", { pairId: partner.pairId });
    setView("idle");
    setPartner(null);
  }, [socket, partner]);

  const leave = useCallback(() => {
    if (!partner) return;
    socket?.emit("chat:leave", { pairId: partner.pairId });
    setView("idle");
    setPartner(null);
  }, [socket, partner]);

  const sendMessage = useCallback(
    (payload: { text?: string; imageUrl?: string; gifUrl?: string }) => {
      if (!partner) return;
      socket?.emit("chat:message", { pairId: partner.pairId, ...payload });
    },
    [socket, partner]
  );

  const setTyping = useCallback(
    (isTyping: boolean) => {
      if (!partner) return;
      socket?.emit("chat:typing", { pairId: partner.pairId, isTyping });
    },
    [socket, partner]
  );

  const submitReport = useCallback(
    (reason: string, details?: string) => {
      if (!partner) return;
      socket?.emit("user:report", { pairId: partner.pairId, reason, details });
      toast({ title: "Report submitted", description: "Thanks for helping keep Drift safe.", variant: "success" });
    },
    [socket, partner, toast]
  );

  const blockUser = useCallback(() => {
    if (!partner) return;
    socket?.emit("user:block", { pairId: partner.pairId });
    setView("idle");
    setPartner(null);
    toast({ title: "User blocked", description: "You won't be matched with them again.", variant: "success" });
  }, [socket, partner, toast]);

  // Keyboard shortcuts: Esc = skip, Ctrl+Enter handled in composer
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape" && view === "matched") skip();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [view, skip]);

  return (
    <div className="relative flex min-h-[100svh] flex-col">
      <AnimatedBackground />

      <AnimatePresence mode="wait">
        {view !== "matched" ? (
          <motion.div key="queue" exit={{ opacity: 0 }}>
            <QueueScreen
              searching={view === "searching"}
              position={queuePosition}
              onlineCount={onlineCount}
              onStart={startQueue}
              onCancel={cancelQueue}
            />
          </motion.div>
        ) : (
          <motion.div key="chat" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex min-h-[100svh] flex-col">
            <ChatHeader
              partnerHandle={partner?.anonHandle ?? null}
              partnerCountry={partner?.country}
              sharedInterests={partner?.sharedInterests ?? []}
              quality={connected ? quality : "disconnected"}
              onSkip={skip}
              onLeave={leave}
              onReport={() => setReportOpen(true)}
              onBlock={blockUser}
            />
            <MessageList messages={messages} selfId={selfId} partnerTyping={partnerTyping} partnerHandle={partner?.anonHandle ?? null} />
            <Composer onSend={sendMessage} onTyping={setTyping} disabled={!connected} />
          </motion.div>
        )}
      </AnimatePresence>

      <ReportDialog open={reportOpen} onOpenChange={setReportOpen} onSubmit={submitReport} />
    </div>
  );
}

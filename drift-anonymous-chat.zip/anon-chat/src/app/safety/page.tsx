import { Navbar, Footer } from "@/components/landing/footer-navbar";
import { AnimatedBackground } from "@/components/landing/animated-background";

export const metadata = { title: "Safety Guidelines" };

export default function SafetyPage() {
  return (
    <main className="relative">
      <AnimatedBackground />
      <Navbar />
      <div className="mx-auto max-w-2xl px-4 pb-20 pt-32 prose prose-invert prose-sm">
        <h1 className="text-3xl font-bold">Safety Guidelines</h1>
        <p className="text-muted-foreground">Drift is built for respectful, anonymous conversation. Please keep these in mind:</p>
        <ul className="mt-4 space-y-2 text-muted-foreground">
          <li>Never share personal information like your real name, address, or financial details.</li>
          <li>Drift is intended for users 18 and older. Report any suspected underage users immediately.</li>
          <li>Harassment, hate speech, and sexually explicit content are not tolerated and may result in an instant ban.</li>
          <li>Use the Report button for any uncomfortable interaction — our moderation team reviews every report.</li>
          <li>Block any user you don't want to be matched with again.</li>
          <li>Trust your instincts. You can end any chat at any time with no explanation needed.</li>
        </ul>
      </div>
      <Footer />
    </main>
  );
}

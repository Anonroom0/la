import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { redis, RedisKeys } from "@/lib/redis";
import { verifyAdminToken } from "@/lib/admin-auth";

function requireAdmin(req: NextRequest) {
  const token = req.cookies.get("drift_admin_token")?.value;
  if (!token) return null;
  return verifyAdminToken(token);
}

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const bans = await prisma.ban.findMany({
    where: { active: true },
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { session: { select: { anonId: true } } },
  });
  return NextResponse.json({ bans });
}

const unbanSchema = z.object({ banId: z.string() });

export async function DELETE(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { banId } = unbanSchema.parse(await req.json());
  const ban = await prisma.ban.update({ where: { id: banId }, data: { active: false } });
  await prisma.session.update({ where: { id: ban.sessionId }, data: { isBanned: false } }).catch(() => void 0);
  await redis.del(RedisKeys.banned(ban.sessionId));

  return NextResponse.json({ ok: true });
}

import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { signAdminToken } from "@/lib/admin-auth";
import crypto from "crypto";

const schema = z.object({
  username: z.string().min(3).max(64),
  password: z.string().min(6).max(128),
});

function hashPassword(password: string) {
  return crypto.createHash("sha256").update(`${password}:${process.env.ADMIN_PASSWORD_SALT || "dev-salt"}`).digest("hex");
}

export async function POST(req: NextRequest) {
  try {
    const body = schema.parse(await req.json());

    // Bootstrap fallback: env-based superadmin for first-run setups without a seeded DB row.
    const envUser = process.env.ADMIN_BOOTSTRAP_USERNAME;
    const envPass = process.env.ADMIN_BOOTSTRAP_PASSWORD;
    if (envUser && envPass && body.username === envUser && body.password === envPass) {
      const token = signAdminToken({ sub: "bootstrap", username: envUser, role: "superadmin" });
      const res = NextResponse.json({ ok: true });
      res.cookies.set("drift_admin_token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 60 * 60 * 12,
        path: "/",
      });
      return res;
    }

    const admin = await prisma.admin.findUnique({ where: { username: body.username } });
    if (!admin || admin.passwordHash !== hashPassword(body.password)) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }

    await prisma.admin.update({ where: { id: admin.id }, data: { lastLoginAt: new Date() } });

    const token = signAdminToken({ sub: admin.id, username: admin.username, role: admin.role as "moderator" | "superadmin" });
    const res = NextResponse.json({ ok: true });
    res.cookies.set("drift_admin_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 60 * 60 * 12,
      path: "/",
    });
    return res;
  } catch (err) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}

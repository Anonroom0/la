import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { verifyAdminToken } from "@/lib/admin-auth";

function requireAdmin(req: NextRequest) {
  const token = req.cookies.get("drift_admin_token")?.value;
  if (!token) return null;
  return verifyAdminToken(token);
}

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const status = req.nextUrl.searchParams.get("status") || "pending";
  const reports = await prisma.report.findMany({
    where: { status },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return NextResponse.json({ reports });
}

const updateSchema = z.object({
  reportId: z.string(),
  action: z.enum(["dismiss", "ban_temp", "ban_permanent"]),
});

export async function POST(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { reportId, action } = updateSchema.parse(await req.json());
  const report = await prisma.report.findUnique({ where: { id: reportId } });
  if (!report) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (action === "dismiss") {
    await prisma.report.update({ where: { id: reportId }, data: { status: "dismissed", reviewedAt: new Date(), reviewedBy: admin.username } });
  } else {
    const expiresAt = action === "ban_temp" ? new Date(Date.now() + 24 * 60 * 60 * 1000) : null;
    await prisma.$transaction([
      prisma.ban.create({
        data: { sessionId: report.reportedId, reason: `Report: ${report.reason}`, issuedBy: admin.username, expiresAt },
      }),
      prisma.session.update({ where: { id: report.reportedId }, data: { isBanned: true } }),
      prisma.report.update({ where: { id: reportId }, data: { status: "actioned", reviewedAt: new Date(), reviewedBy: admin.username } }),
    ]);
  }

  return NextResponse.json({ ok: true });
}

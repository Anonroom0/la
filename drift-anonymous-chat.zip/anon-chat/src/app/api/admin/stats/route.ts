import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { redis, RedisKeys } from "@/lib/redis";
import { verifyAdminToken } from "@/lib/admin-auth";

function requireAdmin(req: NextRequest) {
  const token = req.cookies.get("drift_admin_token")?.value;
  if (!token) return null;
  return verifyAdminToken(token);
}

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [onlineCount, pendingReports, activeBans, totalSessions24h, recentEvents] = await Promise.all([
    redis.scard(RedisKeys.onlineUsers),
    prisma.report.count({ where: { status: "pending" } }),
    prisma.ban.count({ where: { active: true, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] } }),
    prisma.session.count({ where: { createdAt: { gt: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
    prisma.analyticsEvent.findMany({ orderBy: { createdAt: "desc" }, take: 50 }),
  ]);

  const matchesToday = await prisma.chatPair.count({
    where: { startedAt: { gt: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
  });

  return NextResponse.json({
    onlineCount,
    pendingReports,
    activeBans,
    totalSessions24h,
    matchesToday,
    recentEvents,
  });
}

import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      { userAgent: "*", allow: "/", disallow: ["/admin", "/api/"] },
    ],
    sitemap: `${process.env.NEXT_PUBLIC_APP_URL || "https://drift.chat"}/sitemap.xml`,
  };
}

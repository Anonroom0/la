"use client";

import { useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import { Users, Flag, Ban, Activity, LogOut, CheckCircle2, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";
import { timeAgo } from "@/lib/utils";

interface Stats {
  onlineCount: number;
  pendingReports: number;
  activeBans: number;
  totalSessions24h: number;
  matchesToday: number;
  recentEvents: { id: string; type: string; createdAt: string; sessionId: string | null }[];
}

interface Report {
  id: string;
  reporterId: string;
  reportedId: string;
  reason: string;
  details?: string;
  messageSnapshot?: string;
  createdAt: string;
}

interface BanRow {
  id: string;
  sessionId: string;
  reason: string;
  issuedBy: string;
  createdAt: string;
  expiresAt: string | null;
  session?: { anonId: string };
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: number | string }) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-5">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15">
          <Icon className="h-5 w-5 text-primary" />
        </div>
        <div>
          <p className="text-2xl font-bold leading-none">{value}</p>
          <p className="mt-1 text-xs text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [reports, setReports] = useState<Report[]>([]);
  const [bans, setBans] = useState<BanRow[]>([]);
  const [tab, setTab] = useState<"overview" | "reports" | "bans">("overview");

  const loadAll = useCallback(async () => {
    const [statsRes, reportsRes, bansRes] = await Promise.all([
      fetch("/api/admin/stats"),
      fetch("/api/admin/reports?status=pending"),
      fetch("/api/admin/bans"),
    ]);
    if (statsRes.status === 401) {
      router.push("/admin");
      return;
    }
    setStats(await statsRes.json());
    setReports((await reportsRes.json()).reports);
    setBans((await bansRes.json()).bans);
  }, [router]);

  useEffect(() => {
    loadAll();
    const interval = setInterval(loadAll, 10000);
    return () => clearInterval(interval);
  }, [loadAll]);

  const actionReport = async (reportId: string, action: "dismiss" | "ban_temp" | "ban_permanent") => {
    await fetch("/api/admin/reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reportId, action }),
    });
    loadAll();
  };

  const unban = async (banId: string) => {
    await fetch("/api/admin/bans", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ banId }),
    });
    loadAll();
  };

  return (
    <div className="min-h-screen bg-drift-bg px-4 py-8 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Moderation dashboard</h1>
            <p className="text-sm text-muted-foreground">Live overview of Drift's platform health</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => { document.cookie = "drift_admin_token=; Max-Age=0; path=/"; router.push("/admin"); }}>
            <LogOut className="h-4 w-4" /> Sign out
          </Button>
        </div>

        <div className="mb-6 flex gap-2">
          {(["overview", "reports", "bans"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-xl px-4 py-2 text-sm font-medium capitalize transition-colors ${
                tab === t ? "bg-primary text-primary-foreground" : "glass text-muted-foreground hover:text-foreground"
              }`}
            >
              {t} {t === "reports" && stats ? `(${stats.pendingReports})` : ""}
            </button>
          ))}
        </div>

        {tab === "overview" && stats && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
              <StatCard icon={Users} label="Online now" value={stats.onlineCount} />
              <StatCard icon={Activity} label="New sessions (24h)" value={stats.totalSessions24h} />
              <StatCard icon={Activity} label="Matches today" value={stats.matchesToday} />
              <StatCard icon={Flag} label="Pending reports" value={stats.pendingReports} />
              <StatCard icon={Ban} label="Active bans" value={stats.activeBans} />
            </div>

            <Card className="mt-6">
              <CardHeader><CardTitle className="text-base">Recent activity log</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {stats.recentEvents.map((e) => (
                  <div key={e.id} className="flex items-center justify-between border-b border-white/5 py-2 text-sm last:border-0">
                    <span className="font-mono text-xs text-muted-foreground">{e.sessionId?.slice(0, 8) ?? "system"}</span>
                    <Badge variant="outline">{e.type}</Badge>
                    <span className="text-xs text-muted-foreground">{timeAgo(e.createdAt)}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {tab === "reports" && (
          <div className="space-y-3">
            {reports.length === 0 && <p className="text-sm text-muted-foreground">No pending reports. 🎉</p>}
            {reports.map((r) => (
              <Card key={r.id}>
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <Badge variant="destructive">{r.reason}</Badge>
                      <span className="ml-2 text-xs text-muted-foreground">{timeAgo(r.createdAt)}</span>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => actionReport(r.id, "dismiss")}>
                        <XCircle className="h-3.5 w-3.5" /> Dismiss
                      </Button>
                      <Button size="sm" variant="secondary" onClick={() => actionReport(r.id, "ban_temp")}>
                        24h ban
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => actionReport(r.id, "ban_permanent")}>
                        <CheckCircle2 className="h-3.5 w-3.5" /> Permanent ban
                      </Button>
                    </div>
                  </div>
                  {r.details && <p className="mt-2 text-sm">{r.details}</p>}
                  {r.messageSnapshot && (
                    <p className="mt-2 rounded-lg bg-black/30 p-2 font-mono text-xs text-muted-foreground">{r.messageSnapshot}</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {tab === "bans" && (
          <div className="space-y-3">
            {bans.length === 0 && <p className="text-sm text-muted-foreground">No active bans.</p>}
            {bans.map((b) => (
              <Card key={b.id}>
                <CardContent className="flex flex-wrap items-center justify-between gap-3 p-5">
                  <div>
                    <p className="font-medium">{b.session?.anonId ?? b.sessionId.slice(0, 10)}</p>
                    <p className="text-xs text-muted-foreground">{b.reason} · issued by {b.issuedBy} · {timeAgo(b.createdAt)}</p>
                    <p className="text-xs text-muted-foreground">{b.expiresAt ? `Expires ${new Date(b.expiresAt).toLocaleString()}` : "Permanent"}</p>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => unban(b.id)}>Lift ban</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

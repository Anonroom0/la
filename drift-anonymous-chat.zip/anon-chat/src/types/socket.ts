export interface ChatMessage {
  id: string;
  pairId: string;
  senderId: string;
  text?: string;
  imageUrl?: string;
  gifUrl?: string;
  createdAt: string;
  status: "sent" | "delivered" | "read";
}

export interface MatchPreferences {
  genderPref: "any" | "male" | "female";
  countryPref: string; // "any" or ISO code
  interests: string[];
}

export interface MatchedPartner {
  pairId: string;
  anonHandle: string;
  country?: string;
  sharedInterests: string[];
}

export type ConnectionQuality = "excellent" | "good" | "poor" | "disconnected";

/** Client -> Server events */
export interface ClientToServerEvents {
  "queue:join": (prefs: MatchPreferences) => void;
  "queue:leave": () => void;
  "chat:message": (payload: { pairId: string; text?: string; imageUrl?: string; gifUrl?: string }) => void;
  "chat:typing": (payload: { pairId: string; isTyping: boolean }) => void;
  "chat:read": (payload: { pairId: string; messageId: string }) => void;
  "chat:skip": (payload: { pairId: string }) => void;
  "chat:leave": (payload: { pairId: string }) => void;
  "user:report": (payload: { pairId: string; reason: string; details?: string }) => void;
  "user:block": (payload: { pairId: string }) => void;
  "ping:latency": (clientSentAt: number) => void;
}

/** Server -> Client events */
export interface ServerToClientEvents {
  "queue:waiting": (payload: { position: number; estimatedSeconds: number }) => void;
  "queue:matched": (payload: MatchedPartner) => void;
  "chat:message": (message: ChatMessage) => void;
  "chat:typing": (payload: { isTyping: boolean }) => void;
  "chat:read": (payload: { messageId: string }) => void;
  "chat:partner-left": (payload: { reason: "skip" | "leave" | "disconnect" | "banned" }) => void;
  "user:warning": (payload: { message: string }) => void;
  "user:banned": (payload: { reason: string; expiresAt: string | null }) => void;
  "presence:online-count": (count: number) => void;
  "pong:latency": (rttMs: number) => void;
  "error:rate-limited": (payload: { bucket: string; retryAfterSeconds: number }) => void;
}

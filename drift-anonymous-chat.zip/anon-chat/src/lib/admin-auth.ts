import jwt from "jsonwebtoken";

const SECRET = process.env.ADMIN_JWT_SECRET || "dev-secret-change-me";

export interface AdminTokenPayload {
  sub: string;
  username: string;
  role: "moderator" | "superadmin";
}

export function signAdminToken(payload: AdminTokenPayload): string {
  return jwt.sign(payload, SECRET, { expiresIn: "12h" });
}

export function verifyAdminToken(token: string): AdminTokenPayload | null {
  try {
    return jwt.verify(token, SECRET) as AdminTokenPayload;
  } catch {
    return null;
  }
}

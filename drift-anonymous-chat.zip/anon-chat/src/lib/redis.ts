import Redis from "ioredis";

const globalForRedis = globalThis as unknown as { redis?: Redis };

export const redis =
  globalForRedis.redis ??
  new Redis(process.env.REDIS_URL || "redis://localhost:6379", {
    maxRetriesPerRequest: 3,
    lazyConnect: false,
  });

if (process.env.NODE_ENV !== "production") globalForRedis.redis = redis;

// ---- Redis key namespaces used across the app ----
export const RedisKeys = {
  queue: (gender: string, country: string) => `queue:${gender}:${country}`,
  queueGlobal: "queue:any:any",
  onlineUsers: "presence:online",
  socketSession: (socketId: string) => `socket:${socketId}`,
  sessionSocket: (sessionId: string) => `session:${sessionId}:socket`,
  activePair: (sessionId: string) => `pair:${sessionId}`,
  rateLimit: (sessionId: string, bucket: string) => `rl:${bucket}:${sessionId}`,
  typing: (pairId: string) => `typing:${pairId}`,
  banned: (fingerprint: string) => `banned:${fingerprint}`,
  stats: "stats:global",
};

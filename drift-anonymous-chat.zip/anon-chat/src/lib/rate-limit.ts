import { redis, RedisKeys } from "./redis";

interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterSeconds?: number;
}

/**
 * Sliding-window-ish fixed window rate limiter backed by Redis INCR + EXPIRE.
 * bucket examples: "message", "queue_join", "report"
 */
export async function rateLimit(
  sessionId: string,
  bucket: string,
  limit: number,
  windowSeconds: number
): Promise<RateLimitResult> {
  const key = RedisKeys.rateLimit(sessionId, bucket);
  const count = await redis.incr(key);
  if (count === 1) {
    await redis.expire(key, windowSeconds);
  }
  if (count > limit) {
    const ttl = await redis.ttl(key);
    return { allowed: false, remaining: 0, retryAfterSeconds: ttl > 0 ? ttl : windowSeconds };
  }
  return { allowed: true, remaining: limit - count };
}

// Common presets used across the app
export const RateLimits = {
  message: (sessionId: string) => rateLimit(sessionId, "message", 15, 10), // 15 msgs / 10s
  queueJoin: (sessionId: string) => rateLimit(sessionId, "queue_join", 10, 30),
  report: (sessionId: string) => rateLimit(sessionId, "report", 5, 300),
  skip: (sessionId: string) => rateLimit(sessionId, "skip", 20, 60),
};

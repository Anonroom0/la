import crypto from "crypto";

const ADJECTIVES = [
  "Swift", "Hidden", "Silent", "Crimson", "Lunar", "Quiet", "Electric", "Velvet",
  "Frosty", "Golden", "Shadow", "Mystic", "Neon", "Cosmic", "Amber", "Arctic",
  "Wild", "Lucid", "Stellar", "Rogue", "Phantom", "Azure", "Wandering", "Vivid",
];

const NOUNS = [
  "Falcon", "Otter", "Comet", "Fox", "Wolf", "Raven", "Tiger", "Lynx", "Panda",
  "Eagle", "Heron", "Drifter", "Nomad", "Voyager", "Wanderer", "Sparrow", "Orca",
  "Maverick", "Phoenix", "Panther", "Stag", "Wren", "Jaguar", "Kestrel",
];

/** Generates a friendly, memorable anonymous handle like "MysticFalcon482" */
export function generateAnonHandle(): string {
  const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
  const num = Math.floor(100 + Math.random() * 899);
  return `${adj}${noun}${num}`;
}

/** Hashes a raw value (IP, device fingerprint) with a server-side pepper so raw PII is never stored. */
export function hashIdentity(value: string): string {
  const pepper = process.env.IDENTITY_PEPPER || "dev-pepper-change-me";
  return crypto.createHash("sha256").update(`${value}:${pepper}`).digest("hex");
}

export function getClientIp(headers: Headers | Record<string, string | string[] | undefined>): string {
  if (headers instanceof Headers) {
    return headers.get("x-forwarded-for")?.split(",")[0]?.trim() || headers.get("x-real-ip") || "0.0.0.0";
  }
  const fwd = headers["x-forwarded-for"];
  if (typeof fwd === "string") return fwd.split(",")[0].trim();
  if (Array.isArray(fwd)) return fwd[0];
  return "0.0.0.0";
}

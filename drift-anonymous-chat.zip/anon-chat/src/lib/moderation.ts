import Filter from "bad-words";

const filter = new Filter();

// Extra terms relevant to anonymous chat platforms
filter.addWords("kik", "telegram", "onlyfans", "cashapp", "venmo");

export function containsProfanity(text: string): boolean {
  try {
    return filter.isProfane(text);
  } catch {
    return false;
  }
}

export function cleanProfanity(text: string): string {
  try {
    return filter.clean(text);
  } catch {
    return text;
  }
}

/** Heuristic spam detection: repeated chars, all-caps walls, link spam, repeated identical messages. */
export function isLikelySpam(text: string, recentMessages: string[] = []): boolean {
  const trimmed = text.trim();
  if (!trimmed) return false;

  // Excessive character repetition e.g. "aaaaaaaaaaaa"
  if (/(.)\1{9,}/.test(trimmed)) return true;

  // Long all-caps shouting
  if (trimmed.length > 20 && trimmed === trimmed.toUpperCase() && /[A-Z]/.test(trimmed)) return true;

  // Excessive links
  const linkMatches = trimmed.match(/https?:\/\/\S+/gi) || [];
  if (linkMatches.length >= 2) return true;

  // Repeated identical message in short window
  const duplicateCount = recentMessages.filter((m) => m.trim() === trimmed).length;
  if (duplicateCount >= 2) return true;

  return false;
}

/** Basic input sanitization to strip HTML/script content before broadcast or storage. */
export function sanitizeText(input: string): string {
  return input
    .replace(/<[^>]*>?/gm, "")
    .replace(/[\u0000-\u001F\u007F]/g, "")
    .trim()
    .slice(0, 2000);
}

"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { io, type Socket } from "socket.io-client";
import type { ClientToServerEvents, ServerToClientEvents, ConnectionQuality } from "@/types/socket";

const STORAGE_KEY = "drift_session";

interface StoredIdentity {
  sessionId: string;
  anonHandle: string;
}

function loadIdentity(): StoredIdentity | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveIdentity(identity: StoredIdentity) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(identity));
}

export function useSocket() {
  const socketRef = useRef<Socket<ServerToClientEvents, ClientToServerEvents> | null>(null);
  const [connected, setConnected] = useState(false);
  const [quality, setQuality] = useState<ConnectionQuality>("disconnected");
  const [onlineCount, setOnlineCount] = useState(0);

  useEffect(() => {
    const identity = loadIdentity();

    const socket = io({
      auth: {
        sessionId: identity?.sessionId,
        anonHandle: identity?.anonHandle,
        country: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 800,
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      setQuality("good");
    });

    socket.on("disconnect", () => {
      setConnected(false);
      setQuality("disconnected");
    });

    socket.on("presence:online-count", (count) => setOnlineCount(count));

    socket.on("pong:latency", (rtt) => {
      if (rtt < 150) setQuality("excellent");
      else if (rtt < 400) setQuality("good");
      else setQuality("poor");
    });

    const pingInterval = setInterval(() => {
      socket.emit("ping:latency", Date.now());
    }, 5000);

    return () => {
      clearInterval(pingInterval);
      socket.disconnect();
    };
  }, []);

  const persistIdentity = useCallback((sessionId: string, anonHandle: string) => {
    saveIdentity({ sessionId, anonHandle });
  }, []);

  return { socket: socketRef.current, connected, quality, onlineCount, persistIdentity };
}

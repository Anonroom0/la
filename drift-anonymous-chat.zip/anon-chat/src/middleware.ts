import { NextResponse, type NextRequest } from "next/server";
import { verifyAdminToken } from "@/lib/admin-auth";

export function middleware(req: NextRequest) {
  if (req.nextUrl.pathname.startsWith("/admin/dashboard")) {
    const token = req.cookies.get("drift_admin_token")?.value;
    const payload = token ? verifyAdminToken(token) : null;
    if (!payload) {
      return NextResponse.redirect(new URL("/admin", req.url));
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/dashboard/:path*"],
};

"use client";

import { motion } from "framer-motion";
import { ShieldCheck, EyeOff, Flag, Ban, Lock, Database } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const SAFETY_POINTS = [
  { icon: Flag, title: "One-tap reporting", desc: "Report abusive behavior instantly — our moderation team reviews every report." },
  { icon: Ban, title: "Automated bans", desc: "Spam and abuse patterns trigger automatic temporary bans within seconds." },
  { icon: ShieldCheck, title: "Smart filtering", desc: "Built-in profanity and spam detection runs on every message before delivery." },
];

const PRIVACY_POINTS = [
  { icon: EyeOff, title: "No identity stored", desc: "We never ask for your name, email, or phone number. Ever." },
  { icon: Lock, title: "Hashed fingerprints", desc: "Device signals used for abuse prevention are one-way hashed, never stored raw." },
  { icon: Database, title: "Ephemeral messages", desc: "Chat messages aren't persisted after your session ends, by default." },
];

function PointGrid({ points }: { points: typeof SAFETY_POINTS }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
      {points.map((p, i) => (
        <motion.div
          key={p.title}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: i * 0.08 }}
        >
          <Card className="h-full">
            <CardContent className="p-6">
              <p.icon className="mb-3 h-6 w-6 text-drift-violet" />
              <h3 className="font-semibold">{p.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{p.desc}</p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

export function SafetySection() {
  return (
    <section id="safety" className="relative px-4 py-20">
      <div className="mx-auto max-w-6xl">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold sm:text-4xl">Safety comes first</h2>
          <p className="mt-3 text-muted-foreground">Real-time moderation keeps Drift welcoming for everyone.</p>
        </div>
        <PointGrid points={SAFETY_POINTS} />
      </div>
    </section>
  );
}

export function PrivacySection() {
  return (
    <section id="privacy" className="relative px-4 py-20">
      <div className="mx-auto max-w-6xl">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold sm:text-4xl">Your privacy, protected</h2>
          <p className="mt-3 text-muted-foreground">Anonymous by design — not just by promise.</p>
        </div>
        <PointGrid points={PRIVACY_POINTS} />
      </div>
    </section>
  );
}

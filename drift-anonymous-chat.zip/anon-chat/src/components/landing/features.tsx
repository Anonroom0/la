"use client";

import { motion } from "framer-motion";
import { Zap, Globe2, Tags, ShieldCheck, MessageCircleHeart, Smartphone } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const FEATURES = [
  { icon: Zap, title: "Instant matching", desc: "Our queue engine pairs you with a stranger in seconds, powered by Redis." },
  { icon: Tags, title: "Interest tags", desc: "Match with people who share your interests for better conversations." },
  { icon: Globe2, title: "Country filters", desc: "Optionally match within or outside your region." },
  { icon: ShieldCheck, title: "Active moderation", desc: "Spam detection, profanity filtering, and one-tap reporting keep it civil." },
  { icon: MessageCircleHeart, title: "Rich messaging", desc: "Emoji, GIFs, images, typing indicators, and read receipts." },
  { icon: Smartphone, title: "Built for mobile", desc: "A fluid, installable PWA experience on any screen size." },
];

export function Features() {
  return (
    <section className="relative px-4 py-24 sm:py-32">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto mb-16 max-w-2xl text-center"
        >
          <h2 className="text-3xl font-bold sm:text-4xl">Everything you need, nothing you don't</h2>
          <p className="mt-4 text-muted-foreground">A premium chat experience designed for speed, privacy, and real connection.</p>
        </motion.div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.07 }}
            >
              <Card className="h-full transition-transform duration-300 hover:-translate-y-1 hover:bg-white/[0.06]">
                <CardContent className="p-6">
                  <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-drift-violet/30 to-drift-cyan/20">
                    <f.icon className="h-5 w-5 text-drift-cyan" />
                  </div>
                  <h3 className="font-semibold">{f.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

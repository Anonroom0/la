import Link from "next/link";
import { MessageCircle, Github, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-white/[0.06] px-4 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-drift-violet" />
          <span className="font-semibold">Drift</span>
          <span className="text-xs text-muted-foreground ml-2">© {new Date().getFullYear()}</span>
        </div>
        <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <Link href="/privacy" className="hover:text-foreground transition-colors">Privacy</Link>
          <Link href="/safety" className="hover:text-foreground transition-colors">Safety</Link>
          <Link href="/about" className="hover:text-foreground transition-colors">About</Link>
          <Link href="/chat" className="hover:text-foreground transition-colors">Start Chat</Link>
        </nav>
        <div className="flex items-center gap-4 text-muted-foreground">
          <Github className="h-4 w-4 hover:text-foreground transition-colors cursor-pointer" />
          <Twitter className="h-4 w-4 hover:text-foreground transition-colors cursor-pointer" />
        </div>
      </div>
    </footer>
  );
}

export function Navbar() {
  return (
    <header className="fixed top-0 z-40 w-full px-4 py-4">
      <div className="mx-auto flex max-w-6xl items-center justify-between rounded-2xl glass px-4 py-2.5">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <MessageCircle className="h-5 w-5 text-drift-violet" />
          Drift
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground sm:flex">
          <Link href="#safety" className="hover:text-foreground transition-colors">Safety</Link>
          <Link href="#privacy" className="hover:text-foreground transition-colors">Privacy</Link>
          <Link href="/about" className="hover:text-foreground transition-colors">About</Link>
        </nav>
        <Link
          href="/chat"
          className="rounded-xl bg-gradient-to-r from-drift-violet to-drift-cyan px-4 py-2 text-sm font-medium text-white shadow-lg shadow-primary/25 transition-transform hover:scale-105 active:scale-95"
        >
          Start Chat
        </Link>
      </div>
    </header>
  );
}

"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const FAQS = [
  { q: "Do I need to create an account?", a: "No. Drift assigns you a random anonymous handle each session — no email, phone, or password required." },
  { q: "Are my conversations saved?", a: "By default, messages are not persisted after your chat ends. Only moderation-relevant metadata (like report snapshots) is retained briefly." },
  { q: "How does matching work?", a: "When you join the queue, our Redis-backed matchmaking engine pairs you with a compatible stranger based on your optional filters and shared interests — typically in a few seconds." },
  { q: "Can I choose who I talk to?", a: "You can set optional gender and country preferences and add interest tags. You can also skip to a new match anytime." },
  { q: "What happens if someone is abusive?", a: "Tap Report during any chat. Our automated systems also detect spam and profanity in real time, and repeated violations trigger temporary bans." },
  { q: "Is Drift free?", a: "Yes, Drift is free to use with no hidden paywalls." },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="relative px-4 py-20">
      <div className="mx-auto max-w-3xl">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold sm:text-4xl">Frequently asked questions</h2>
        </div>
        <div className="space-y-3">
          {FAQS.map((item, i) => (
            <div key={item.q} className="glass overflow-hidden rounded-xl">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between px-5 py-4 text-left text-sm font-medium"
                aria-expanded={open === i}
              >
                {item.q}
                <ChevronDown className={cn("h-4 w-4 shrink-0 transition-transform duration-300", open === i && "rotate-180")} />
              </button>
              <AnimatePresence initial={false}>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <p className="px-5 pb-4 text-sm text-muted-foreground">{item.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

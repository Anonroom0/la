"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, Sparkles, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FloatingParticles } from "./floating-particles";

export function Hero({ onlineCount = 0 }: { onlineCount?: number }) {
  return (
    <section className="relative flex min-h-[100svh] flex-col items-center justify-center px-4 text-center overflow-hidden">
      <FloatingParticles />

      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="glass mb-8 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground"
      >
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
        </span>
        {onlineCount > 0 ? `${onlineCount.toLocaleString()} people online now` : "Live matchmaking, zero signup"}
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.1 }}
        className="max-w-4xl text-balance text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl md:text-7xl"
      >
        Talk to someone new.
        <br />
        <span className="text-gradient bg-200% animate-gradient-shift">Completely anonymous.</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="mt-6 max-w-xl text-balance text-lg text-muted-foreground"
      >
        Drift pairs you instantly with a stranger for real, unfiltered conversation.
        No accounts, no profiles, no history — just the moment.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.3 }}
        className="mt-10 flex flex-col items-center gap-4 sm:flex-row"
      >
        <Button asChild size="lg" variant="gradient" className="group min-w-[220px] text-base">
          <Link href="/chat">
            <Sparkles className="h-5 w-5" />
            Start Chatting
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </Button>
        <Button asChild size="lg" variant="outline" className="min-w-[180px] text-base">
          <Link href="#safety">
            <Users className="h-5 w-5" />
            How it works
          </Link>
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.6 }}
        className="mt-16 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-xs text-muted-foreground"
      >
        <span>✓ No registration</span>
        <span>✓ End-to-end moderated</span>
        <span>✓ Free forever</span>
        <span>✓ Works on any device</span>
      </motion.div>

      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="h-9 w-5 rounded-full border border-white/20 p-1">
          <div className="h-1.5 w-1.5 rounded-full bg-white/60" />
        </div>
      </motion.div>
    </section>
  );
}

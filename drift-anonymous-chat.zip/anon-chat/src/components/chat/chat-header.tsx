"use client";

import { motion } from "framer-motion";
import { SkipForward, Flag, ShieldOff, LogOut, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { ConnectionQuality } from "@/types/socket";

interface ChatHeaderProps {
  partnerHandle: string | null;
  partnerCountry?: string;
  sharedInterests: string[];
  quality: ConnectionQuality;
  onSkip: () => void;
  onLeave: () => void;
  onReport: () => void;
  onBlock: () => void;
}

const QUALITY_CONFIG: Record<ConnectionQuality, { label: string; color: string }> = {
  excellent: { label: "Excellent", color: "bg-emerald-400" },
  good: { label: "Good", color: "bg-emerald-400" },
  poor: { label: "Poor connection", color: "bg-amber-400" },
  disconnected: { label: "Disconnected", color: "bg-rose-400" },
};

export function ChatHeader({ partnerHandle, partnerCountry, sharedInterests, quality, onSkip, onLeave, onReport, onBlock }: ChatHeaderProps) {
  const q = QUALITY_CONFIG[quality];

  return (
    <motion.header
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass sticky top-0 z-20 flex items-center justify-between gap-3 px-4 py-3"
    >
      <div className="flex min-w-0 items-center gap-3">
        <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-drift-violet to-drift-cyan font-semibold text-white">
          {partnerHandle ? partnerHandle[0] : "?"}
          <span className={cn("absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background", q.color)} />
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{partnerHandle ?? "Waiting…"}</p>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            {quality === "disconnected" ? <WifiOff className="h-3 w-3" /> : <Wifi className="h-3 w-3" />}
            {q.label}
            {partnerCountry && <span>· {partnerCountry}</span>}
          </div>
        </div>
        {sharedInterests.length > 0 && (
          <Badge variant="success" className="hidden shrink-0 sm:inline-flex">
            {sharedInterests.length} shared interest{sharedInterests.length > 1 ? "s" : ""}
          </Badge>
        )}
      </div>

      <div className="flex shrink-0 items-center gap-1.5">
        <Button variant="ghost" size="icon" title="Report" onClick={onReport}>
          <Flag className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" title="Block" onClick={onBlock}>
          <ShieldOff className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="sm" onClick={onSkip} title="Skip (Esc)">
          <SkipForward className="h-4 w-4" /> <span className="hidden sm:inline">Skip</span>
        </Button>
        <Button variant="ghost" size="icon" title="Leave" onClick={onLeave}>
          <LogOut className="h-4 w-4" />
        </Button>
      </div>
    </motion.header>
  );
}

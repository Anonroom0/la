"use client";

import { useEffect, useRef } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Check, CheckCheck } from "lucide-react";
import { cn, formatTimestamp } from "@/lib/utils";
import type { ChatMessage } from "@/types/socket";

interface MessageListProps {
  messages: ChatMessage[];
  selfId: string;
  partnerTyping: boolean;
  partnerHandle: string | null;
}

function Bubble({ message, isSelf }: { message: ChatMessage; isSelf: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 30 }}
      className={cn("flex w-full", isSelf ? "justify-end" : "justify-start")}
    >
      <div className={cn("max-w-[78%] sm:max-w-[65%]", isSelf ? "items-end" : "items-start", "flex flex-col gap-1")}>
        <div
          className={cn(
            "rounded-2xl px-4 py-2.5 text-sm leading-relaxed break-words",
            isSelf
              ? "bg-gradient-to-br from-drift-violet to-drift-violet/80 text-white rounded-br-md"
              : "glass rounded-bl-md"
          )}
        >
          {message.text && <p>{message.text}</p>}
          {message.imageUrl && (
            <div className="relative mt-1 h-48 w-48 overflow-hidden rounded-lg">
              <Image src={message.imageUrl} alt="Shared image" fill className="object-cover" unoptimized />
            </div>
          )}
          {message.gifUrl && (
            <div className="relative mt-1 h-40 w-48 overflow-hidden rounded-lg">
              <Image src={message.gifUrl} alt="GIF" fill className="object-cover" unoptimized />
            </div>
          )}
        </div>
        <div className={cn("flex items-center gap-1 px-1 text-[10px] text-muted-foreground", isSelf ? "flex-row-reverse" : "")}>
          <span>{formatTimestamp(message.createdAt)}</span>
          {isSelf && (message.status === "read" ? <CheckCheck className="h-3 w-3 text-drift-cyan" /> : <Check className="h-3 w-3" />)}
        </div>
      </div>
    </motion.div>
  );
}

export function TypingIndicator({ handle }: { handle: string }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
      <div className="glass flex items-center gap-1 rounded-2xl rounded-bl-md px-4 py-3">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="h-1.5 w-1.5 rounded-full bg-muted-foreground"
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15 }}
          />
        ))}
      </div>
      <span className="text-xs text-muted-foreground">{handle} is typing…</span>
    </motion.div>
  );
}

export function MessageList({ messages, selfId, partnerTyping, partnerHandle }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, partnerTyping]);

  return (
    <div className="custom-scrollbar flex-1 space-y-3 overflow-y-auto px-4 py-4">
      <AnimatePresence initial={false}>
        {messages.map((m) => (
          <Bubble key={m.id} message={m} isSelf={m.senderId === selfId} />
        ))}
      </AnimatePresence>
      <AnimatePresence>{partnerTyping && <TypingIndicator handle={partnerHandle ?? "Stranger"} />}</AnimatePresence>
      <div ref={bottomRef} />
    </div>
  );
}

"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, Users, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import type { MatchPreferences } from "@/types/socket";

interface QueueScreenProps {
  searching: boolean;
  position: number;
  onlineCount: number;
  onStart: (prefs: MatchPreferences) => void;
  onCancel: () => void;
}

const INTEREST_SUGGESTIONS = ["music", "gaming", "movies", "books", "travel", "sports", "art", "tech"];

export function QueueScreen({ searching, position, onlineCount, onStart, onCancel }: QueueScreenProps) {
  const [gender, setGender] = useState<"any" | "male" | "female">("any");
  const [country, setCountry] = useState("any");
  const [interestInput, setInterestInput] = useState("");
  const [interests, setInterests] = useState<string[]>([]);

  const addInterest = (tag: string) => {
    const clean = tag.trim().toLowerCase();
    if (clean && !interests.includes(clean) && interests.length < 5) {
      setInterests([...interests, clean]);
    }
    setInterestInput("");
  };

  return (
    <div className="flex min-h-[100svh] flex-col items-center justify-center px-4 text-center">
      {!searching ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <div className="glass mx-auto mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs text-muted-foreground">
            <Users className="h-3.5 w-3.5" />
            {onlineCount.toLocaleString()} online now
          </div>
          <h1 className="text-3xl font-bold">Set your preferences</h1>
          <p className="mt-2 text-sm text-muted-foreground">Optional — leave as "Any" for the fastest match.</p>

          <div className="mt-8 space-y-4 text-left">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Gender preference</label>
              <Select value={gender} onValueChange={(v) => setGender(v as typeof gender)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any</SelectItem>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Country preference</label>
              <Select value={country} onValueChange={setCountry}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any country</SelectItem>
                  <SelectItem value="US">United States</SelectItem>
                  <SelectItem value="GB">United Kingdom</SelectItem>
                  <SelectItem value="CA">Canada</SelectItem>
                  <SelectItem value="AU">Australia</SelectItem>
                  <SelectItem value="DE">Germany</SelectItem>
                  <SelectItem value="IN">India</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Interests (up to 5)</label>
              <Input
                value={interestInput}
                onChange={(e) => setInterestInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addInterest(interestInput))}
                placeholder="Type and press enter…"
              />
              <div className="mt-2 flex flex-wrap gap-1.5">
                {INTEREST_SUGGESTIONS.filter((s) => !interests.includes(s)).slice(0, 5).map((s) => (
                  <button key={s} onClick={() => addInterest(s)} className="text-xs">
                    <Badge variant="outline" className="cursor-pointer hover:bg-white/10">+ {s}</Badge>
                  </button>
                ))}
              </div>
              {interests.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {interests.map((tag) => (
                    <Badge key={tag} className="gap-1">
                      {tag}
                      <X className="h-3 w-3 cursor-pointer" onClick={() => setInterests(interests.filter((t) => t !== tag))} />
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>

          <Button
            variant="gradient"
            size="lg"
            className="mt-8 w-full text-base"
            onClick={() => onStart({ genderPref: gender, countryPref: country, interests })}
          >
            Find a stranger
          </Button>
        </motion.div>
      ) : (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center">
          <div className="relative mb-8 flex h-24 w-24 items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-primary/20 animate-pulse-ring" />
            <div className="absolute inset-2 rounded-full bg-primary/20 animate-pulse-ring [animation-delay:0.4s]" />
            <Loader2 className="h-9 w-9 animate-spin text-primary" />
          </div>
          <h2 className="text-xl font-semibold">Finding someone for you…</h2>
          {position > 0 && <p className="mt-1 text-sm text-muted-foreground">Position in queue: {position}</p>}
          <Button variant="outline" className="mt-8" onClick={onCancel}>
            Cancel
          </Button>
        </motion.div>
      )}
    </div>
  );
}

"use client";

import { useRef, useState } from "react";
import dynamic from "next/dynamic";
import { Smile, ImagePlus, Send, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const EmojiPicker = dynamic(() => import("emoji-picker-react"), { ssr: false });

interface ComposerProps {
  onSend: (payload: { text?: string; imageUrl?: string; gifUrl?: string }) => void;
  onTyping: (isTyping: boolean) => void;
  disabled?: boolean;
}

export function Composer({ onSend, onTyping, disabled }: ComposerProps) {
  const [value, setValue] = useState("");
  const [showEmoji, setShowEmoji] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeout = useRef<ReturnType<typeof setTimeout>>();

  const handleChange = (v: string) => {
    setValue(v);
    onTyping(true);
    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => onTyping(false), 1500);
  };

  const send = () => {
    const text = value.trim();
    if (!text || disabled) return;
    onSend({ text });
    setValue("");
    onTyping(false);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return; // 5MB cap
    const reader = new FileReader();
    reader.onload = () => {
      onSend({ imageUrl: reader.result as string });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  return (
    <div className="glass relative border-t border-white/[0.06] px-3 py-3 sm:px-4">
      {showEmoji && (
        <div className="absolute bottom-full right-3 mb-2 z-30">
          <EmojiPicker
            theme={"dark" as any}
            onEmojiClick={(emoji) => handleChange(value + emoji.emoji)}
            width={320}
            height={400}
          />
        </div>
      )}

      <div className="flex items-end gap-2">
        <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageSelect} />
        <Button variant="ghost" size="icon" onClick={() => fileInputRef.current?.click()} title="Send image" disabled={disabled}>
          <ImagePlus className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => setShowEmoji((s) => !s)} title="Emoji" disabled={disabled}>
          <Smile className="h-5 w-5" />
        </Button>

        <Input
          value={value}
          onChange={(e) => handleChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
          placeholder={disabled ? "Waiting for a match…" : "Type a message…"}
          disabled={disabled}
          className="flex-1"
          aria-label="Message input"
        />

        <Button variant="gradient" size="icon" onClick={send} disabled={disabled || !value.trim()} title="Send (Enter)">
          <Send className="h-4 w-4" />
        </Button>
      </div>
      <p className="mt-1.5 hidden text-[10px] text-muted-foreground sm:block">
        <Sparkles className="mr-1 inline h-2.5 w-2.5" />
        Enter to send · Shift+Enter for newline · Esc to skip
      </p>
    </div>
  );
}

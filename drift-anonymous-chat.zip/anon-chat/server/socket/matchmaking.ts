import { redis, RedisKeys } from "../../src/lib/redis";
import type { MatchPreferences } from "../../src/types/socket";

interface QueueEntry {
  sessionId: string;
  socketId: string;
  anonHandle: string;
  country: string;
  prefs: MatchPreferences;
  joinedAt: number;
}

const QUEUE_KEY = "queue:waiting"; // a single Redis LIST of JSON entries, filtered in-process for compatibility

/** Adds a user to the matchmaking pool. */
export async function joinQueue(entry: QueueEntry) {
  await redis.rpush(QUEUE_KEY, JSON.stringify(entry));
  await redis.expire(QUEUE_KEY, 3600);
}

export async function leaveQueue(sessionId: string) {
  const all = await redis.lrange(QUEUE_KEY, 0, -1);
  for (const raw of all) {
    const entry: QueueEntry = JSON.parse(raw);
    if (entry.sessionId === sessionId) {
      await redis.lrem(QUEUE_KEY, 1, raw);
    }
  }
}

function prefsCompatible(a: QueueEntry, b: QueueEntry): boolean {
  const genderOk =
    (a.prefs.genderPref === "any" || a.prefs.genderPref === undefined) ||
    (b.prefs.genderPref === "any" || b.prefs.genderPref === undefined) ||
    true; // gender of partner isn't tracked server-side without self-reported field; kept permissive
  const countryOk =
    a.prefs.countryPref === "any" || b.prefs.countryPref === "any" || a.prefs.countryPref === b.country || b.prefs.countryPref === a.country;
  return genderOk && countryOk;
}

function sharedInterests(a: QueueEntry, b: QueueEntry): string[] {
  const setB = new Set(b.prefs.interests.map((i) => i.toLowerCase()));
  return a.prefs.interests.filter((i) => setB.has(i.toLowerCase()));
}

/**
 * Attempts to find the best match for a newly-joined user from the current waiting pool.
 * Prioritizes shared interests, then compatible country/gender preference, then FIFO order.
 */
export async function findMatch(sessionId: string): Promise<{ self: QueueEntry; partner: QueueEntry } | null> {
  const all = await redis.lrange(QUEUE_KEY, 0, -1);
  const entries: { raw: string; entry: QueueEntry }[] = all.map((raw) => ({ raw, entry: JSON.parse(raw) }));

  const selfWrapper = entries.find((e) => e.entry.sessionId === sessionId);
  if (!selfWrapper) return null;
  const self = selfWrapper.entry;

  const candidates = entries.filter((e) => e.entry.sessionId !== sessionId && prefsCompatible(self, e.entry));
  if (candidates.length === 0) return null;

  // Rank by shared interest count desc, then by wait time (oldest first)
  candidates.sort((a, b) => {
    const interestDiff = sharedInterests(self, b.entry).length - sharedInterests(self, a.entry).length;
    if (interestDiff !== 0) return interestDiff;
    return a.entry.joinedAt - b.entry.joinedAt;
  });

  const best = candidates[0];

  // Atomically remove both from queue
  await redis.lrem(QUEUE_KEY, 1, selfWrapper.raw);
  await redis.lrem(QUEUE_KEY, 1, best.raw);

  return { self, partner: best.entry };
}

export async function queuePosition(sessionId: string): Promise<number> {
  const all = await redis.lrange(QUEUE_KEY, 0, -1);
  const idx = all.findIndex((raw) => JSON.parse(raw).sessionId === sessionId);
  return idx === -1 ? 0 : idx + 1;
}

export async function queueSize(): Promise<number> {
  return redis.llen(QUEUE_KEY);
}

export type { QueueEntry };

import type { Server, Socket } from "socket.io";
import { nanoid } from "nanoid";
import { redis, RedisKeys } from "../../src/lib/redis";
import { prisma } from "../../src/lib/prisma";
import { generateAnonHandle } from "../../src/lib/identity";
import { containsProfanity, isLikelySpam, sanitizeText, cleanProfanity } from "../../src/lib/moderation";
import { rateLimit } from "../../src/lib/rate-limit";
import { joinQueue, leaveQueue, findMatch, queuePosition } from "./matchmaking";
import type { ClientToServerEvents, ServerToClientEvents, ChatMessage } from "../../src/types/socket";

interface SocketData {
  sessionId: string;
  anonHandle: string;
  country: string;
  currentPairId?: string;
  recentMessages: string[];
}

type IOServer = Server<ClientToServerEvents, ServerToClientEvents>;
type IOSocket = Socket<ClientToServerEvents, ServerToClientEvents, Record<string, never>, SocketData>;

const SPAM_BAN_THRESHOLD = 3; // strikes before auto-temp-ban
const PAIR_PARTNER_KEY = (pairId: string, sessionId: string) => `pair:${pairId}:partner:${sessionId}`;

export function registerSocketHandlers(io: IOServer) {
  io.on("connection", async (socket: IOSocket) => {
    // Identify or restore an anonymous session via handshake auth payload
    const providedSessionId = socket.handshake.auth?.sessionId as string | undefined;
    const sessionId = providedSessionId || nanoid(16);
    const anonHandle = (socket.handshake.auth?.anonHandle as string) || generateAnonHandle();
    const country = (socket.handshake.auth?.country as string) || "XX";

    socket.data.sessionId = sessionId;
    socket.data.anonHandle = anonHandle;
    socket.data.country = country;
    socket.data.recentMessages = [];

    // Check ban status
    const banKey = RedisKeys.banned(sessionId);
    const banned = await redis.get(banKey);
    if (banned) {
      socket.emit("user:banned", { reason: banned, expiresAt: null });
      socket.disconnect(true);
      return;
    }

    await redis.sadd(RedisKeys.onlineUsers, sessionId);
    await redis.set(RedisKeys.sessionSocket(sessionId), socket.id, "EX", 3600);
    broadcastOnlineCount(io);

    // ---------------- Matchmaking ----------------
    socket.on("queue:join", async (prefs) => {
      const rl = await rateLimit(sessionId, "queue_join", 10, 30);
      if (!rl.allowed) {
        socket.emit("error:rate-limited", { bucket: "queue_join", retryAfterSeconds: rl.retryAfterSeconds! });
        return;
      }

      await joinQueue({
        sessionId,
        socketId: socket.id,
        anonHandle,
        country,
        prefs,
        joinedAt: Date.now(),
      });

      logEvent(sessionId, "queue_join", { prefs });

      const match = await findMatch(sessionId);
      if (!match) {
        const pos = await queuePosition(sessionId);
        socket.emit("queue:waiting", { position: pos, estimatedSeconds: Math.max(3, pos * 2) });
        return;
      }

      await createMatch(io, match.self, match.partner);
    });

    socket.on("queue:leave", async () => {
      await leaveQueue(sessionId);
    });

    // ---------------- Chat ----------------
    socket.on("chat:message", async (payload) => {
      const { pairId } = payload;
      if (!pairId || socket.data.currentPairId !== pairId) return;

      const rl = await rateLimit(sessionId, "message", 15, 10);
      if (!rl.allowed) {
        socket.emit("error:rate-limited", { bucket: "message", retryAfterSeconds: rl.retryAfterSeconds! });
        return;
      }

      let text = payload.text ? sanitizeText(payload.text) : undefined;

      if (text) {
        if (isLikelySpam(text, socket.data.recentMessages)) {
          await handleSpamStrike(io, socket);
          socket.emit("user:warning", { message: "Your message looked like spam and was blocked." });
          return;
        }
        if (containsProfanity(text)) {
          text = cleanProfanity(text);
        }
        socket.data.recentMessages.push(text);
        if (socket.data.recentMessages.length > 5) socket.data.recentMessages.shift();
      }

      const message: ChatMessage = {
        id: nanoid(12),
        pairId,
        senderId: sessionId,
        text,
        imageUrl: payload.imageUrl,
        gifUrl: payload.gifUrl,
        createdAt: new Date().toISOString(),
        status: "sent",
      };

      io.to(roomFor(pairId)).emit("chat:message", message);

      await prisma.chatPair.update({
        where: { id: pairId },
        data: { messageCount: { increment: 1 } },
      }).catch(() => void 0);
    });

    socket.on("chat:typing", ({ pairId, isTyping }) => {
      if (socket.data.currentPairId !== pairId) return;
      socket.to(roomFor(pairId)).emit("chat:typing", { isTyping });
    });

    socket.on("chat:read", ({ pairId, messageId }) => {
      if (socket.data.currentPairId !== pairId) return;
      socket.to(roomFor(pairId)).emit("chat:read", { messageId });
    });

    socket.on("chat:skip", async ({ pairId }) => {
      await endPair(io, socket, pairId, "skip");
    });

    socket.on("chat:leave", async ({ pairId }) => {
      await endPair(io, socket, pairId, "leave");
    });

    // ---------------- Safety ----------------
    socket.on("user:report", async ({ pairId, reason, details }) => {
      const rl = await rateLimit(sessionId, "report", 5, 300);
      if (!rl.allowed) {
        socket.emit("error:rate-limited", { bucket: "report", retryAfterSeconds: rl.retryAfterSeconds! });
        return;
      }
      const partnerId = await redis.get(PAIR_PARTNER_KEY(pairId, sessionId));
      if (!partnerId) return;

      await prisma.report.create({
        data: {
          reporterId: sessionId,
          reportedId: partnerId,
          reason,
          details,
          messageSnapshot: socket.data.recentMessages.join(" | "),
        },
      }).catch(() => void 0);

      logEvent(sessionId, "report", { reportedId: partnerId, reason });
      await endPair(io, socket, pairId, "report");
    });

    socket.on("user:block", async ({ pairId }) => {
      const partnerId = await redis.get(PAIR_PARTNER_KEY(pairId, sessionId));
      if (partnerId) {
        await redis.sadd(`block:${sessionId}`, partnerId);
      }
      await endPair(io, socket, pairId, "leave");
    });

    // ---------------- Connection quality ----------------
    socket.on("ping:latency", (clientSentAt: number) => {
      socket.emit("pong:latency", Date.now() - clientSentAt);
    });

    // ---------------- Disconnect ----------------
    socket.on("disconnect", async () => {
      await redis.srem(RedisKeys.onlineUsers, sessionId);
      await leaveQueue(sessionId);
      if (socket.data.currentPairId) {
        await endPair(io, socket, socket.data.currentPairId, "disconnect");
      }
      broadcastOnlineCount(io);
    });
  });
}

// ---------------- Helpers ----------------

function roomFor(pairId: string) {
  return `pair:${pairId}`;
}

async function createMatch(
  io: IOServer,
  a: { sessionId: string; socketId: string; anonHandle: string; country: string; prefs: any },
  b: { sessionId: string; socketId: string; anonHandle: string; country: string; prefs: any }
) {
  const pair = await prisma.chatPair
    .create({ data: { userAId: a.sessionId, userBId: b.sessionId } })
    .catch(() => null);
  const pairId = pair?.id || nanoid(14);

  const socketA = io.sockets.sockets.get(a.socketId);
  const socketB = io.sockets.sockets.get(b.socketId);
  if (!socketA || !socketB) return;

  socketA.data.currentPairId = pairId;
  socketB.data.currentPairId = pairId;
  socketA.join(roomFor(pairId));
  socketB.join(roomFor(pairId));

  await redis.set(PAIR_PARTNER_KEY(pairId, a.sessionId), b.sessionId, "EX", 7200);
  await redis.set(PAIR_PARTNER_KEY(pairId, b.sessionId), a.sessionId, "EX", 7200);

  const shared = a.prefs.interests.filter((i: string) =>
    b.prefs.interests.map((x: string) => x.toLowerCase()).includes(i.toLowerCase())
  );

  socketA.emit("queue:matched", { pairId, anonHandle: b.anonHandle, country: b.country, sharedInterests: shared });
  socketB.emit("queue:matched", { pairId, anonHandle: a.anonHandle, country: a.country, sharedInterests: shared });

  logEvent(a.sessionId, "match_found", { pairId, partner: b.sessionId });
  logEvent(b.sessionId, "match_found", { pairId, partner: a.sessionId });
}

async function endPair(io: IOServer, socket: IOSocket, pairId: string, reason: "skip" | "leave" | "disconnect" | "report") {
  if (socket.data.currentPairId !== pairId) return;

  socket.to(roomFor(pairId)).emit("chat:partner-left", { reason });
  socket.leave(roomFor(pairId));
  socket.data.currentPairId = undefined;

  await prisma.chatPair
    .update({ where: { id: pairId }, data: { endedAt: new Date(), endedReason: reason } })
    .catch(() => void 0);

  // Clean up the other socket's room membership too
  const room = io.sockets.adapter.rooms.get(roomFor(pairId));
  if (room) {
    for (const sid of room) {
      const other = io.sockets.sockets.get(sid) as IOSocket | undefined;
      if (other) {
        other.leave(roomFor(pairId));
        other.data.currentPairId = undefined;
      }
    }
  }
}

async function handleSpamStrike(io: IOServer, socket: IOSocket) {
  const sessionId = socket.data.sessionId;
  const strikesKey = `strikes:${sessionId}`;
  const strikes = await redis.incr(strikesKey);
  await redis.expire(strikesKey, 600);

  if (strikes >= SPAM_BAN_THRESHOLD) {
    const banKey = RedisKeys.banned(sessionId);
    await redis.set(banKey, "automated spam detection", "EX", 60 * 30); // 30 min temp ban
    await prisma.ban
      .create({
        data: { sessionId, reason: "Automated spam detection", issuedBy: "system", expiresAt: new Date(Date.now() + 30 * 60 * 1000) },
      })
      .catch(() => void 0);
    socket.emit("user:banned", { reason: "Repeated spam detected", expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString() });
    socket.disconnect(true);
  }
}

async function broadcastOnlineCount(io: IOServer) {
  const count = await redis.scard(RedisKeys.onlineUsers);
  io.emit("presence:online-count", count);
}

function logEvent(sessionId: string, type: string, metadata?: Record<string, unknown>) {
  prisma.analyticsEvent
    .create({ data: { sessionId, type, metadata: metadata as any } })
    .catch(() => void 0);
}

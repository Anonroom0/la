import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import next from "next";
import { registerSocketHandlers } from "./socket/handlers";
import type { ClientToServerEvents, ServerToClientEvents } from "../src/types/socket";

const dev = process.env.NODE_ENV !== "production";
const port = parseInt(process.env.PORT || "3000", 10);
const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const server = express();

  // ---- Security middleware ----
  server.use(
    helmet({
      contentSecurityPolicy: dev ? false : undefined, // relax CSP in dev for HMR
      crossOriginEmbedderPolicy: false,
    })
  );
  server.disable("x-powered-by");

  // Global HTTP rate limit (separate from Socket.IO message rate limiting)
  server.use(
    "/api/",
    rateLimit({
      windowMs: 60 * 1000,
      max: 60,
      standardHeaders: true,
      legacyHeaders: false,
    })
  );

  const httpServer = createServer(server);

  const io = new Server<ClientToServerEvents, ServerToClientEvents>(httpServer, {
    cors: {
      origin: process.env.NEXT_PUBLIC_APP_URL || "*",
      credentials: true,
    },
    pingInterval: 10000,
    pingTimeout: 5000,
  });

  registerSocketHandlers(io);

  // Hand everything else to Next.js
  server.all("*", (req, res) => handle(req, res));

  httpServer.listen(port, () => {
    console.log(`🚀 Drift server ready on http://localhost:${port} (${dev ? "dev" : "prod"})`);
  });
});

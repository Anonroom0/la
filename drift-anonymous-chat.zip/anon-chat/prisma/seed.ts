import { PrismaClient } from "@prisma/client";
import crypto from "crypto";

const prisma = new PrismaClient();

function hashPassword(password: string) {
  return crypto.createHash("sha256").update(`${password}:${process.env.ADMIN_PASSWORD_SALT || "dev-salt"}`).digest("hex");
}

async function main() {
  const username = process.env.ADMIN_BOOTSTRAP_USERNAME || "admin";
  const password = process.env.ADMIN_BOOTSTRAP_PASSWORD || "changeme123";

  await prisma.admin.upsert({
    where: { username },
    update: {},
    create: { username, passwordHash: hashPassword(password), role: "superadmin" },
  });

  console.log(`Seeded admin user "${username}". Remember to change the default password.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
